## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/build-an-interactive-bird-flying-game-using-javascript-dom-video/9781838823702)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Practice-a-JavaScript-DOM-Exercise-to-Build-a-Bird-Flying-Game
Code Repository for Practice a JavaScript DOM Exercise to Build a Bird Flying Game, published by Packt
